/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user
 */
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
public class Magic8BallGame implements ActionListener{
  JFrame frame;
  JLabel M8B;
    public static void main(String[] args) {
        Magic8BallGame gui = new Magic8BallGame();
        gui.start();
    }
    
   public void start(){
   JLabel question = new JLabel("Ask the great 8 ball anything:");
   JTextField text = new JTextField(8);
   M8B = new JLabel("Magic 8 ball says...");
   frame = new JFrame();
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   JButton askButton = new JButton("Ask");
//   JButton exitButton = new JButton("Quit");
   askButton.addActionListener(this);
//   exitButton.addActionListener(this);
   frame.getContentPane().add(BorderLayout.CENTER, M8B);
   frame.getContentPane().add(BorderLayout.SOUTH,askButton);
//   frame.getContentPane().add(BorderLayout.SOUTH,exitButton);
   frame.setSize(400,300);
   frame.setVisible(true);
   
   JPanel panel = new JPanel();
   //panel.setLayout(new BorderLayout(panel,BoxLayout.PAGE_AXIS));
   panel.add(question);
   panel.add(text);
   frame.getContentPane().add(BorderLayout.CENTER,panel);
    }
   
   public void actionPerformed(ActionEvent event){
       ArrayList<String> answer = new ArrayList <String>();
       answer.add("I don't think I should answer that");
       answer.add("No");
       answer.add("Yes");
       answer.add("More or less");
       answer.add("Don't count on it");
       answer.add("Ask again");
       
       Random results = new Random();
       int randomResults = results.nextInt(8);
       M8B.setText(answer.get(randomResults));
      
   }
   
}
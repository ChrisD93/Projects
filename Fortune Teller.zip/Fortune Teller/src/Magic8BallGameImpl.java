
public class Magic8BallGameImpl extends Magic8BallGame {
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class PaintPanel extends JPanel{
    private int pointCount = 0;
    private Point[] points = new Point[1000];
    
    public PaintPanel(){
        addMouseMotionListener(
            new MouseMotionAdapter(){
                public void mouseDragged(MouseEvent event){
                    if(pointCount < points.length){
                        points[pointCount]= event.getPoint();
                        ++pointCount;
                        repaint();
                    }
                }
            }
        );
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        for(int j = 0; j < pointCount; j++)
            g.fillOval(points[j].x, points[j].y,4,4);
    }
}

